import json
import csv

# Open the JSON file for reading
with open('C:/Users/Admin/Desktop/Case Study/Imply Case Study/POC/CityListA.json', 'r') as json_file:
    data = json.load(json_file)

# Define the path for the CSV file
csv_file_path = 'C:/Users/Admin/Desktop/Case Study/Imply Case Study/POC/CityListA.csv'

# Write the data to a CSV file
with open(csv_file_path, 'w', newline='', encoding='utf-8') as csv_file:
    csv_writer = csv.writer(csv_file)
    
    # Write the header row
    header = ['Name', 'CountryCode', 'Population']
    csv_writer.writerow(header)
    
    # Write the data rows
    for city in data:
        csv_writer.writerow([city['Name'], city['CountryCode'], city['Population']])

print(f'CSV file has been created at: {csv_file_path}')
