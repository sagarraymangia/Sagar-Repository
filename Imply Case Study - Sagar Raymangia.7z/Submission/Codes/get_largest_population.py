import pandas as pd

# Read data from merged CSV file
merged_df = pd.read_csv("MergedCityList.csv")

# Find the city with the largest population
city_with_largest_population = merged_df[merged_df["Population"] == merged_df["Population"].max()]

# Print the city with the largest population
print("City with the largest population:")
print(city_with_largest_population)


