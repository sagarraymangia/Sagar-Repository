import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.file.DataFileReader;
import org.apache.avro.file.FileReader;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class AvroToCsvConverter {
    public static void main(String[] args) throws IOException {
        String avroFilePath = "C:/Users/Admin/Desktop/Case Study/Imply Case Study/POC/CityListB.avro";
        String csvFilePath = "C:/Users/Admin/Desktop/Case Study/Imply Case Study/POC/CityListB.csv";

        // Infer the Avro schema from the Avro data
        Schema schema = null;
        try (FileReader<GenericRecord> fileReader = DataFileReader.openReader(new File(avroFilePath), new GenericDatumReader<>())) {
            schema = fileReader.getSchema();
        }

        try (FileWriter csvWriter = new FileWriter(csvFilePath)) {
            try (FileReader<GenericRecord> fileReader = DataFileReader.openReader(new File(avroFilePath), new GenericDatumReader<>(schema))) {
                for (GenericRecord record : fileReader) {
                    // Customize the following line based on your Avro schema structure
                    String csvLine = String.format("%s,%s,%s",
                            record.get("Name"), record.get("CountryCode"), record.get("Population"));
                    csvWriter.write(csvLine);
                    csvWriter.write(System.lineSeparator());
                }
            }
        }

        System.out.println("CSV file has been created at: " + csvFilePath);
    }
}
