import pandas as pd

# Read data from merged CSV file
merged_df = pd.read_csv("MergedCityList.csv")

# Get the count of all rows
row_count = merged_df.shape[0]

# Print the count of all rows
print("Total number of rows:", row_count)


