import pandas as pd

# Read data from merged CSV file
merged_df = pd.read_csv("MergedCityList.csv")

# Filter cities in Brazil (CountryCode == "BRA")
brazil_cities = merged_df[merged_df["CountryCode"] == "BRA"]

# Calculate the total population of Brazil cities
total_population_brazil = brazil_cities["Population"].sum()

# Print the total population of Brazil cities
print("Total population of all cities in Brazil:", total_population_brazil)


