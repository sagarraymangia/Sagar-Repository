import pandas as pd

# Read data from CSV files
df_a = pd.read_csv("C:/Users/Admin/Desktop/Case Study/Imply Case Study/POC/CityList.csv")
df_b = pd.read_csv("C:/Users/Admin/Desktop/Case Study/Imply Case Study/POC/CityListA.csv")
df_c = pd.read_csv("C:/Users/Admin/Desktop/Case Study/Imply Case Study/POC/CityListB.csv")

# Concatenate dataframes
combined_df = pd.concat([df_a, df_b, df_c])

# Remove duplicates based on Cityname and Countrycode
combined_df.drop_duplicates(subset=["Name", "CountryCode"], inplace=True)

# Sort the dataframe alphabetically by Cityname
combined_df.sort_values(by="Name", inplace=True)

# Write the merged and sorted dataframe to a CSV file
combined_df.to_csv("MergedCityList.csv", index=False)


